package actividades_refuerzo;

import java.util.Scanner;

public class Actividad_17 {
    public static void main(String[] args) {
        // Variables
        String hora;

        // Inicializamos la variable Scanner para obtener los datos por teclado
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Dime una hora en formato (HH:mm:ss) => ");
        hora = lector.next();

        // 

        lector.close();

    }   
}
