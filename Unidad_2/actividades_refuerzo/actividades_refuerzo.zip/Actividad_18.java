package actividades_refuerzo;

public class Actividad_18 {
    public static void main(String[] args) {
        float horas;
        
        
        float tarifaMas35;
        int impuestos900 = 25;
        int demasImpuestos = 45;

    }
}
