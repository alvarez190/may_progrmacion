package actividades_refuerzo;

public class Actividad_2 {
    public static void main(String[] args) {
        // Vaiables
        int ladoCuadrado = 5;
        int area;

        // Calulo el area del cuadrado

        area = ladoCuadrado * ladoCuadrado;

        // Muestro el resultado
        System.out.println("El area de un cuadrado de lado " + ladoCuadrado + " es " + area);
    }
}
