package actividades_refuerzo;

public class Actividad_1 {
    public static void main(String[] args) {
        System.out.println("Buenos dias");
    }
}       
